clc;
clear all;
close all;

n=[-5:5];
a=2*(imseq(2,-5,5))-(imseq(-4,-5,5));
stem(n,a);

